%parcial 2 20240619
clear all;clc;close all
%VdeE x1=v (torque) x2=vdot x3=teta x4=tetadot entrada u salida y=x3=teta
% Estado de Equilibrio a 30 grados
ue=0.5; 
x1e=0.5;
x2e=0;
x3e=pi/6;
x4e=0;
ye=x3e;
wn=2*pi*50


% Usamos las variables como simbolicas
syms x1 x2 x3 x4 u y;
x = [x1; x2; x3; x4];

% Se arma las funciones de derivadas (f) en este caso un vector dim4
f1 = x2   ;
f2 = -wn^2 * x1 - 2*wn*x2 + wn^2 * u;
f3 = x4
f4 = x1 - sin(x3)
f = [f1; f2; f3; f4];

% Salida y el angulo del pendulo
y = x3;

% Jacobianos
A = jacobian(f,x);
B = jacobian(f,u);
C = jacobian(y,x);
D = jacobian(y,u);

% Evaluar el jacobiano en los valores de equilibrio
A = subs(A, str2sym({'x1', 'x2','x3','x4', 'u', 'y'}), {x1e, x2e, x3e, x4e, ue, ye});
B = subs(B, str2sym({'x1', 'x2','x3','x4', 'u', 'y'}), {x1e, x2e, x3e, x4e, ue, ye});
C = subs(C, str2sym({'x1', 'x2','x3','x4', 'u', 'y'}), {x1e, x2e, x3e, x4e, ue, ye});
D = subs(D, str2sym({'x1', 'x2','x3','x4', 'u', 'y'}), {x1e, x2e, x3e, x4e, ue, ye});

Ass = double(A)
Bss = double(B)
Css = double(C)
Dss = double(D)
% ojo a43 matlab lo da como -1 pero es -0.86
P = zpk(ss(Ass, Bss, Css, Dss))


% COMPENSACION

% Parametros Bode
optionss=bodeoptions;
optionss.MagVisible='on';
optionss.PhaseMatching='on';
optionss.PhaseMatchingValue=-180;
optionss.PhaseMatchingFreq=1;
optionss.Grid='on';

% Diseño del controller
% Accion integral 
% cero doble -sqrt(0.866) 
% polo en -wn  para regularizar el controller
% dejo k en 1 para analizar el MF
k = 1;
C = zpk([-sqrt(0.866) -sqrt(0.866)],[-wn 0],k);
figure();
bode(minreal(C*P), optionss);
title('L = C*P con k=1');


% Ajusto k para que MF=75º (veo que lo hace en W=18 rad/seg)
k = db2mag(75)
C = zpk([-sqrt(0.866) -sqrt(0.866)],[-wn 0],k);
figure();
bode(minreal(C*P), optionss);
title('L = C*P con k=5623');

%%
% Pade para digitalizar
[Gm,Pm,Wcg,Wcp] = margin(C*P)
Phase_dig = 14;    %Utilizo 14° para digitalizacion
Ts = (2*Phase_dig*pi)/(180*Wcp);
s = tf('s');
Pd = (1 - Ts/4 * s)/(1 + Ts/4 * s);
L=C*P*Pd;
figure();
bode(minreal(C*P*Pd), optionss);
title('L = C*P con C digitalizado');


%Grupo de las 4
S=minreal(1/(1+C*Pd*P))
T=1-S
CS=minreal(C*S)
PS=minreal(P*S)
figure();
bode(minreal(C*P*Pd), optionss);
title('L = C*P con C digitalizado');
figure();
bode(L,S,T,PS,optionss);
figure();

step(PS,10);title('PS');grid on
step(5*T,10);title('PS');grid on
%%

% Paso el controlador a discreto
C_digital = c2d(C, Ts, 'tustin');


% En el simulink le sumo los 30 grados en la entrada de referencia asi
% parte todo desde pi/6. Uso constantes de escalado hacia el osciloscopio
% para leer en grados
